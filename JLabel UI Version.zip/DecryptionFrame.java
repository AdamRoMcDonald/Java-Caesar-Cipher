import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class DecryptionFrame extends JFrame {

    private final JTextField messageField;
    private final JTextField keyField;
    private final JTextArea decryptedMessageArea;


    public DecryptionFrame(){
        super("Decrypt");
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 3));

        JLabel messageLabel = new JLabel("Enter Message: ");


        JLabel keyLabel = new JLabel("Enter Key: ");
        keyField = new JTextField();

        messageField = new JTextField();
        JButton decryptButton = new JButton("Decrypt");
        decryptedMessageArea = new JTextArea(10, 40);
        decryptedMessageArea.setEditable(false);
        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageField.getText();
                int key;

                if (!keyField.getText().isEmpty()) {
                    try {
                        key = Integer.parseInt(keyField.getText());
                        decryptedMessageArea.setText(decryptMessage(message, key));

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(DecryptionFrame.this,
                                "Invalid key. Please enter a valid integer key.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    try {
                        decryptedMessageArea.setText(attemptDecryptions(message));
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        inputPanel.add(messageLabel);
        inputPanel.add(messageField);
        inputPanel.add(keyLabel);
        inputPanel.add(keyField);
        inputPanel.add(decryptButton);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(decryptedMessageArea), BorderLayout.CENTER);

        pack();
    }

    private String decryptMessage(String message, int key) throws IOException {
        KeyAndMessageObj MKPair = new KeyAndMessageObj();
        MKPair.setMessage(message);
        MKPair.setKey(key);
        return MKPair.CaesarCipher(message, -key); // Decrypt with negative key
    }

    private String attemptDecryptions(String message) throws IOException {
        KeyAndMessageObj MKPair = new KeyAndMessageObj();
        MKPair.setMessage(message);
        MKPair.EnglishWordChecker("words_alpha.txt");

        StringBuilder decryptedOptions = new StringBuilder();


        String mess = MKPair.getMessage();
        char someChar = ' ';
        int count = 0;
        for (int i = 0; i < mess.length(); i++) {
            if (mess.charAt(i) == someChar) {
                count++;
            }
        }
        if (count > 0) {
            String[] seperatedWords = MKPair.getMessage().split(" ");
            for (String c : seperatedWords) {

                MKPair.setMessage(c);
                for (int i = 0; i <= 26; i++) {
                    if (MKPair.isEnglishWord(MKPair.CaesarCipher(MKPair.getMessage(), -i))) {
                        decryptedOptions.append("Key ").append(i).append(": ").append(MKPair.CaesarCipher(MKPair.getMessage(), -i)).append("\n");
                    }

                }
            }
        }




        for (int i = 0; i < 26; i++) {
            String decryptedMessage = MKPair.CaesarCipher(message, -i);
            if (MKPair.isEnglishWord(decryptedMessage)) {
                decryptedOptions.append("Key ").append(i).append(": ").append(decryptedMessage).append("\n");
            }
        }

        return decryptedOptions.toString();
    }
}
