import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private final JButton encryptButton;
    private final JButton decryptButton;

    private final JButton exitButton;
    private final JButton menuButton;

    public MainFrame(String title) {
        super(title);


        setLayout(new BorderLayout());

        ImageIcon welcomeImage = new ImageIcon("cicada.jpg");

        int newWidth = 150;
        int newHeight = 150;
        Image scaledImage = welcomeImage.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(scaledImage);

        JLabel welcomeLabel = new JLabel("Welcome to the Caesar Cipher Tool!");
        welcomeLabel.setIcon(scaledImageIcon); // Set the image icon
        welcomeLabel.setHorizontalTextPosition(JLabel.CENTER); // Center text relative to the icon
        welcomeLabel.setVerticalTextPosition(JLabel.TOP); // Position text below the icon
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER); // Center the label horizontally
        welcomeLabel.setVerticalAlignment(JLabel.CENTER); // Center the label vertically
        add(welcomeLabel, BorderLayout.NORTH);



        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel horizontalCenterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        horizontalCenterPanel.setBorder(BorderFactory.createEmptyBorder(100, 0, 100, 0)); // Add vertical spacing
        horizontalCenterPanel.add(buttonPanel);



        add(horizontalCenterPanel, BorderLayout.CENTER);







        encryptButton = new JButton("Encrypt");
        decryptButton = new JButton("Decrypt");

        JPanel exitAndMenu = new JPanel();
        exitAndMenu.setLayout(new BoxLayout(exitAndMenu, BoxLayout.Y_AXIS));
        exitAndMenu.setAlignmentX(Component.BOTTOM_ALIGNMENT);

        exitButton = new JButton("Exit");
        menuButton = new JButton("Return to Menu");

        // Action listener for the exit button
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exit the application
            }
        });

        // Action listener for the menu button
        menuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EncryptionFrame encryptionFrame = new EncryptionFrame();
                encryptionFrame.setVisible(true);
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DecryptionFrame decryptionFrame = new DecryptionFrame();
                decryptionFrame.setVisible(true);
            }
        });

        JLabel nameVersion = new JLabel("Adam McDonald, Version 2.0");
        nameVersion.setFont(new Font("Arial", Font.BOLD, 10));


        buttonPanel.add(encryptButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Add some vertical spacing
        buttonPanel.add(decryptButton);

        exitAndMenu.add(exitButton);
        exitAndMenu.add(menuButton);

        exitAndMenu.add(nameVersion);

        add(horizontalCenterPanel, BorderLayout.CENTER);
        add(exitAndMenu, BorderLayout.SOUTH);


        pack();

        setSize(500, 600); // Increased the height to accommodate the exit and menu buttons
    }


}
