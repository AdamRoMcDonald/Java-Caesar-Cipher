import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class EncryptionFrame extends JFrame {
    private final JTextField messageField;
    private final JTextField keyField;
    private final JTextArea encryptedMessageArea;

    public EncryptionFrame() {
        super("Encryption");

        setLayout(new BorderLayout());


        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));

        JLabel messageLabel = new JLabel("Enter Message:");
        JLabel keyLabel = new JLabel("Enter Key:");
        messageField = new JTextField();
        keyField = new JTextField();
        JButton encryptButton = new JButton("Encrypt");
        encryptedMessageArea = new JTextArea(10, 40);
        encryptedMessageArea.setEditable(false);

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String message = messageField.getText();
                    int key = Integer.parseInt(keyField.getText());

                    KeyAndMessageObj MKPair = new KeyAndMessageObj();
                    MKPair.setMessage(message);
                    MKPair.setKey(key);

                    String encryptedMessage = MKPair.CaesarCipher(message, key);
                    encryptedMessageArea.setText(encryptedMessage);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(EncryptionFrame.this,
                            "Invalid key. Please enter a valid integer key.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        inputPanel.add(messageLabel);
        inputPanel.add(messageField);
        inputPanel.add(keyLabel);
        inputPanel.add(keyField);
        inputPanel.add(encryptButton);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(encryptedMessageArea), BorderLayout.CENTER);

        pack();
    }
}
